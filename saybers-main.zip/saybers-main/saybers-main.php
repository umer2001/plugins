<?php
/**
 * Plugin Name: SAYBERS MAIN
 * Plugin URI: http://www.mywebsite.com/my-first-plugin
 * Description: plugin which is nessesery when using saybers theme.
 * Version: 1.0
 * Author: MUHAMMAD UMER FAROOQ 
 * Author URI: https://stackoverflow.com/users/story/11566896
 *License: GNU General Public License v2 or later
 *License URI: LICENSE
 *Text Domain: saybers
 */

if(! defined('ABSPATH')) {
    exit;
}
// Register Custom Post Type portfolio
include( plugin_dir_path( __FILE__ ) .'/inc/portfolio.php');
include( plugin_dir_path( __FILE__ ) .'/inc/testimonial.php');
include( plugin_dir_path( __FILE__ ) .'/inc/team.php');
include( plugin_dir_path( __FILE__ ) .'/inc/service.php');